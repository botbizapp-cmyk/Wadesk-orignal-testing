<?php

namespace App\Services\Instaflow;

use App\Models\SystemSetting;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Facades\Http;

/**
 * The WaDesk → Instaflow bridge.
 *
 * Instaflow runs as its OWN deployment and owns the real Instagram engine
 * (Meta OAuth, webhooks, Graph API). WaDesk never talks to Meta for IG — it
 * talks to Instaflow, and Instaflow's data surfaces in WaDesk's unified inbox.
 *
 * The two prove they share a secret on every call via the X-Instaflow-Secret
 * header — the SAME secret the admin pastes on the Add-ons "Connect Instaflow"
 * card (stored encrypted in SystemSetting). One direction lives here (WaDesk
 * calling Instaflow); the reverse (Instaflow pushing new IG messages to WaDesk)
 * lands on POST /api/instaflow/inbound, guarded by the same secret.
 *
 * Contract (Instaflow must expose, all under {url}, secret in the header):
 *   GET  /api/wadesk/handshake                 → {ok:true, service:"instaflow"}
 *   GET  /api/wadesk/conversations?account=..  → [{id,account,name,handle,avatar,last_at,unread}]
 *   GET  /api/wadesk/conversations/{id}/messages → [{id,from_me,type,text,media_url,at}]
 *   POST /api/wadesk/conversations/{id}/reply  → {ok:true, message_id}   body:{type,text,media_url}
 *   GET  /api/wadesk/accounts                  → [{id,username,name,avatar,connected}]
 */
class InstaflowClient
{
    public function __construct(
        private readonly string $baseUrl = '',
        private readonly string $secret  = '',
    ) {}

    /** Build from the admin-saved connection (URL + shared secret). */
    public static function fromSettings(): self
    {
        return new self(
            rtrim((string) SystemSetting::get('instaflow_url', ''), '/'),
            (string) SystemSetting::get('instaflow_secret', ''),
        );
    }

    /** Is a connection even configured? (URL + secret both present.) */
    public function isConfigured(): bool
    {
        return $this->baseUrl !== '' && $this->secret !== '';
    }

    /** Was the last saved handshake successful? Cheap — reads the stored flag. */
    public function isConnected(): bool
    {
        return $this->isConfigured() && (bool) SystemSetting::get('instaflow_connected', false);
    }

    /** Live handshake — proves reachability + secret match right now. */
    public function handshake(): bool
    {
        if (! $this->isConfigured()) {
            return false;
        }
        try {
            $r = $this->request()->get('/api/wadesk/handshake');
            return $r->successful() && ($r->json('ok') === true || $r->json('service') === 'instaflow');
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** @return array<int, array> IG conversations for the unified inbox. */
    public function conversations(?string $account = null): array
    {
        return $this->safeArray(
            fn () => $this->request()->get('/api/wadesk/conversations', array_filter(['account' => $account]))
        );
    }

    /** @return array<int, array> Messages in one IG conversation. */
    public function messages(string $conversationId): array
    {
        return $this->safeArray(
            fn () => $this->request()->get("/api/wadesk/conversations/{$conversationId}/messages")
        );
    }

    /** @return array<int, array> Connected IG accounts on the Instaflow side. */
    public function accounts(): array
    {
        return $this->safeArray(fn () => $this->request()->get('/api/wadesk/accounts'));
    }

    /**
     * Reply to an IG conversation. Instaflow performs the actual Graph send and
     * returns the provider message id. Returns ['ok'=>bool,'message_id'=>?string,'error'=>?string].
     */
    public function reply(string $conversationId, string $type, ?string $text = null, ?string $mediaUrl = null): array
    {
        if (! $this->isConfigured()) {
            return ['ok' => false, 'error' => 'Instaflow is not connected.'];
        }
        try {
            $r = $this->request()->post("/api/wadesk/conversations/{$conversationId}/reply", array_filter([
                'type'      => $type,
                'text'      => $text,
                'media_url' => $mediaUrl,
            ], fn ($v) => $v !== null));
            if (! $r->successful()) {
                return ['ok' => false, 'error' => 'Instaflow returned HTTP ' . $r->status()];
            }
            return ['ok' => true, 'message_id' => $r->json('message_id')];
        } catch (\Throwable $e) {
            return ['ok' => false, 'error' => $e->getMessage()];
        }
    }

    /** Shared pending HTTP client — secret header + JSON + sane timeout on every call. */
    private function request(): \Illuminate\Http\Client\PendingRequest
    {
        return Http::baseUrl($this->baseUrl)
            ->withHeaders(['X-Instaflow-Secret' => $this->secret])
            ->acceptJson()
            ->timeout(15);
    }

    /** Run a GET that returns a list; never throw into the caller — degrade to []. */
    private function safeArray(callable $call): array
    {
        if (! $this->isConfigured()) {
            return [];
        }
        try {
            /** @var Response $r */
            $r = $call();
            $data = $r->successful() ? $r->json() : null;
            return is_array($data) ? $data : [];
        } catch (\Throwable $e) {
            return [];
        }
    }
}

<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Extension;
use App\Models\SystemSetting;
use App\Services\ExtensionService;
use App\Support\Audit;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

/**
 * Admin → Settings → Extensions.
 *
 * Verify the WaDesk purchase code, upload an extension ZIP, merge it in.
 * Mirrors the Updater's shape (verify → upload → apply) because operators
 * already know that flow, and a second, different-looking installer would be
 * one more thing to learn for no benefit.
 */
class ExtensionController extends Controller
{
    public function __construct(private ExtensionService $extensions) {}

    public function index()
    {
        return view('admin.extensions.index', [
            'extensions'  => Extension::query()->orderBy('name')->get(),
            'coreVersion' => (string) config('version.version', '0.0.0'),
            // Instaflow runs as its OWN deployment — the operator connects to it
            // by URL + shared secret (no code upload). Surface the saved config +
            // last handshake result so the card shows connected / not-connected.
            'instaflowUrl'        => (string) SystemSetting::get('instaflow_url', ''),
            'instaflowConnected'  => (bool) SystemSetting::get('instaflow_connected', false),
            'instaflowLastCheck'  => (string) SystemSetting::get('instaflow_last_check', ''),
            'instaflowHasSecret'  => trim((string) SystemSetting::get('instaflow_secret', '')) !== '',
        ]);
    }

    /**
     * Connect this WaDesk to a standalone Instaflow deployment: save the base
     * URL + shared secret, then run the handshake. Instaflow must expose
     *   GET  {url}/api/wadesk/handshake   (header: X-Instaflow-Secret: <secret>)
     *   → 200 {"ok":true,"service":"instaflow", ...}
     * so both sides prove they share the secret before any data flows. Secret is
     * stored encrypted (SystemSetting::ENCRYPTED_KEYS). No package is uploaded.
     */
    public function connectInstaflow(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'instaflow_url'    => 'required|url|max:255',
            'instaflow_secret' => 'nullable|string|max:255',
        ]);

        $url = rtrim(trim($data['instaflow_url']), '/');
        SystemSetting::set('instaflow_url', $url, 'string', 'Instaflow deployment base URL');

        // A blank secret field means "keep the existing secret" — so the operator
        // can re-test the connection without re-typing it. A non-blank value replaces it.
        $secret = trim((string) ($data['instaflow_secret'] ?? ''));
        if ($secret !== '') {
            SystemSetting::set('instaflow_secret', $secret, 'string', 'Instaflow handshake shared secret');
        } else {
            $secret = (string) SystemSetting::get('instaflow_secret', '');
        }

        // Handshake.
        $connected = false;
        $reason    = '';
        try {
            $resp = Http::withHeaders(['X-Instaflow-Secret' => $secret])
                ->timeout(12)
                ->acceptJson()
                ->get($url . '/api/wadesk/handshake');
            if ($resp->status() === 401 || $resp->status() === 403) {
                $reason = 'Secret rejected by Instaflow (HTTP ' . $resp->status() . ').';
            } elseif (! $resp->successful()) {
                $reason = 'Instaflow returned HTTP ' . $resp->status() . '.';
            } elseif (($resp->json('ok') === true) || ($resp->json('service') === 'instaflow')) {
                $connected = true;
            } else {
                $reason = 'Reached the URL but it did not respond as an Instaflow deployment.';
            }
        } catch (\Throwable $e) {
            $reason = 'Could not reach Instaflow at that URL (' . $e->getMessage() . ').';
        }

        SystemSetting::set('instaflow_connected', $connected ? '1' : '0', 'bool', 'Instaflow handshake result');
        SystemSetting::set('instaflow_last_check', now()->toDateTimeString(), 'string', 'Instaflow last handshake time');

        // Audit::log() takes (string $action, array $opts) — everything else
        // (subject, result, meta) goes INSIDE $opts. Passing them as extra
        // positional args throws a TypeError before the redirect ever runs.
        // `admin.` prefix puts the row on the platform layer, like other
        // operator actions.
        Audit::log('admin.instaflow.connect', [
            'subject_type' => 'instaflow',
            'result'       => $connected ? 'success' : 'failure',
            'meta'         => [
                'url'    => $url,
                'reason' => $connected ? null : $reason,
            ],
        ]);

        return $connected
            ? back()->with('status', 'Instaflow connected.')
            : back()->with('error', 'Instaflow not connected — ' . ($reason ?: 'handshake failed.'));
    }

    /** Step 1 — licence check. Same code that unlocks the Updater. */
    public function verify(Request $request): JsonResponse
    {
        $code = trim((string) $request->input('purchase_code', ''));
        $res  = $this->extensions->verifyPurchase($code);

        Audit::log('admin.extension.verify', [
            'subject_type' => 'extension',
            'result'       => $res['ok'] ? 'success' : 'failure',
            // Never log the licence key itself — only whether it worked.
            'meta'         => ['outcome' => $res['ok'] ? 'valid' : 'invalid'],
        ]);

        return response()->json($res, $res['ok'] ? 200 : 422);
    }

    /**
     * Step 2 — upload + install, in one call.
     *
     * Inspect BEFORE writing anything: a malformed or too-new package is
     * rejected while the install is still untouched. A half-merged extension is
     * much harder to recover from than a refused upload.
     */
    public function upload(Request $request): JsonResponse
    {
        $request->validate([
            'extension'         => 'required|file|mimes:zip|max:102400',   // 100 MB
            'purchase_code' => 'nullable|string|max:191',
        ]);

        $code = trim((string) $request->input('purchase_code', ''));

        // Re-verify server-side. The front-end already checked, but that check
        // is advisory — without this an admin could POST straight to /upload
        // and skip the licence entirely.
        $lic = $this->extensions->verifyPurchase($code);
        if (!($lic['ok'] ?? false)) {
            return response()->json([
                'ok' => false,
                'message' => $lic['message'] ?? 'Verify your purchase code before installing an extension.',
            ], 422);
        }

        try {
            $zipPath = $this->extensions->saveUploadedZip($request->file('extension'));
        } catch (\Throwable $e) {
            return response()->json(['ok' => false, 'message' => 'Could not save the upload: ' . $e->getMessage()], 500);
        }

        $info = $this->extensions->inspect($zipPath);
        if (!$info['ok']) {
            return response()->json($info, 422);
        }

        try {
            $res = $this->extensions->install(
                $zipPath,
                $info['manifest'],
                $info['root'],
                $code ?: null,
                (int) $request->user()->id,
            );
        } catch (\Throwable $e) {
            \Log::error('[EXTENSION] install threw', ['error' => $e->getMessage()]);
            return response()->json(['ok' => false, 'message' => 'Install failed: ' . $e->getMessage()], 500);
        }

        if (!($res['ok'] ?? false)) {
            return response()->json($res, 422);
        }

        Audit::log('admin.extension.installed', [
            'subject_type' => 'extension',
            'meta'         => [
                'slug'    => $info['manifest']['slug'],
                'version' => $info['manifest']['version'],
                'files'   => $res['files'] ?? 0,
            ],
        ]);

        $m = $info['manifest'];
        $skipped = (int) ($res['skipped'] ?? 0);

        // Say plainly if the tables did not get created. Reporting a bare
        // "installed" while migrations failed would send the operator off to
        // debug 500s on a feature that never had its schema.
        $migrationNote = '';
        if (!empty($res['migration_error'])) {
            $migrationNote = ' WARNING: database migration failed — ' . $res['migration_error'];
        } elseif (!empty($res['migrated'])) {
            $migrationNote = ' Database updated.';
        }

        return response()->json([
            'ok' => true,
            'message' => "{$m['name']} {$m['version']} installed — {$res['files']} file(s) merged."
                . ($skipped > 0 ? " {$skipped} protected path(s) skipped." : '')
                . $migrationNote,
            'extension' => $m,
        ]);
    }

    /** Switch an extension off without deleting its files. */
    public function toggle(Request $request, int $id): JsonResponse
    {
        $extension = Extension::findOrFail($id);
        $extension->status = $extension->isActive() ? Extension::STATUS_DISABLED : Extension::STATUS_ACTIVE;
        $extension->save();
        Extension::forget($extension->slug);

        Audit::log('admin.extension.' . ($extension->isActive() ? 'enabled' : 'disabled'), [
            'subject_type' => 'extension',
            'subject_id'   => $extension->id,
            'meta'         => ['slug' => $extension->slug],
        ]);

        return response()->json(['ok' => true, 'status' => $extension->status]);
    }

    public function destroy(Request $request, int $id): JsonResponse
    {
        $extension = Extension::findOrFail($id);
        $slug  = $extension->slug;

        try {
            $res = $this->extensions->uninstall($extension);
        } catch (\Throwable $e) {
            return response()->json(['ok' => false, 'message' => 'Uninstall failed: ' . $e->getMessage()], 500);
        }

        Audit::log('admin.extension.uninstalled', [
            'subject_type' => 'extension',
            'meta'         => ['slug' => $slug, 'removed' => $res['removed'] ?? 0],
        ]);

        return response()->json([
            'ok' => true,
            'message' => "Removed {$slug} — " . ($res['removed'] ?? 0) . ' file(s) deleted.',
        ]);
    }
}

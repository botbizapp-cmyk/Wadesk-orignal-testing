<?php

namespace App\Http\Controllers\Api;

use App\Events\Inbox\MessageReceived;
use App\Http\Controllers\Controller;
use App\Models\Conversation;
use App\Models\InboxMessage;
use App\Models\SystemSetting;
use App\Models\Workspace;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

/**
 * Instaflow → WaDesk push.
 *
 * The separate Instaflow deployment POSTs new Instagram events here so they
 * surface in WaDesk's unified team-inbox (the SAME Conversation + InboxMessage
 * tables WhatsApp uses, with provider = 'instagram' and channel = 'instagram').
 * Authenticated by the SAME shared secret the admin pasted on the Add-ons
 * "Connect Instagram" card — no Laravel session, so this route is outside the
 * web auth group and self-guards.
 *
 * IG threads are keyed by the Instaflow conversation id (never a phone number),
 * namespaced as raw_jid = "ig:<id>" and channel = 'instagram' (which is in
 * Conversation::ENGINE_AGNOSTIC_CHANNELS, so they always show regardless of the
 * workspace's connected WhatsApp engine and never collide with a phone thread).
 *
 * Body (Instaflow sends):
 *   {
 *     "event":        "message" | "status" | "conversation",
 *     "workspace_id": 12,
 *     "account":      { "id":"...", "username":"...", "name":"...", "avatar":"..." },
 *     "conversation": { "id":"...", "name":"...", "handle":"...", "avatar":"..." },
 *     "message":      { "id":"...", "from_me":false, "type":"text|image|video|audio|share|story_reply",
 *                       "text":"...", "media_url":"https://...", "at":"ISO-8601" }
 *   }
 */
class InstaflowInboundController extends Controller
{
    public function ingest(Request $request): JsonResponse
    {
        // ── Auth: constant-time compare against the stored shared secret ──────
        $sent   = (string) $request->header('X-Instaflow-Secret', '');
        $stored = (string) SystemSetting::get('instaflow_secret', '');
        if ($stored === '' || ! hash_equals($stored, $sent)) {
            return response()->json(['ok' => false, 'error' => 'unauthorized'], 401);
        }

        $data = $request->validate([
            'event'        => 'required|string|in:message,status,conversation',
            'workspace_id' => 'required|integer',
            'account'      => 'nullable|array',
            'conversation' => 'nullable|array',
            'message'      => 'nullable|array',
        ]);

        // A real push proves the link is live — reflect that on the Add-ons card.
        SystemSetting::set('instaflow_connected', '1', 'bool', 'Instaflow handshake result');
        SystemSetting::set('instaflow_last_inbound', now()->toDateTimeString(), 'string', 'Instaflow last inbound push');

        $wsId = (int) $data['workspace_id'];
        if (! Workspace::whereKey($wsId)->exists()) {
            return response()->json(['ok' => false, 'error' => 'unknown workspace'], 422);
        }

        // Only 'message' events create inbox rows; status/conversation are
        // acknowledged (they'll drive read-state / thread meta in a later pass).
        if ($data['event'] !== 'message') {
            return response()->json(['ok' => true, 'received' => $data['event']]);
        }

        try {
            $msg = $this->storeMessage($wsId, $data);
        } catch (\Throwable $e) {
            Log::error('[INSTAFLOW] inbound store failed', ['ws' => $wsId, 'err' => $e->getMessage()]);
            return response()->json(['ok' => false, 'error' => 'store_failed'], 500);
        }

        return response()->json(['ok' => true, 'message_id' => $msg->id, 'conversation_id' => $msg->conversation_id]);
    }

    /** Create/refresh the IG thread + append the message, then fan out the event. */
    private function storeMessage(int $wsId, array $data): InboxMessage
    {
        $igConvId = (string) data_get($data, 'conversation.id', '');
        $handle   = trim((string) data_get($data, 'conversation.handle', ''));
        $name     = trim((string) data_get($data, 'conversation.name', ''));
        $title    = $name !== '' ? $name : ($handle !== '' ? '@' . ltrim($handle, '@') : 'Instagram');
        $key      = 'ig:' . ($igConvId !== '' ? $igConvId : 'unknown-' . md5(json_encode($data)));

        // ONE thread per IG conversation — keyed on the namespaced Instaflow id,
        // not a phone number (IG has none). channel='instagram' keeps it out of
        // the phone-number resolver and always visible in the unified inbox.
        $convo = Conversation::firstOrCreate(
            ['workspace_id' => $wsId, 'channel' => 'instagram', 'raw_jid' => $key],
            [
                'title'           => $title,
                'provider'        => 'instagram',
                'origin'          => 'instagram',
                'status'          => 'pending',
                'inbox_status'    => 'open',
                'last_message_at' => now(),
                'contact_digits'  => null,
            ]
        );

        $m   = (array) data_get($data, 'message', []);
        $dir = data_get($m, 'from_me') ? 'out' : 'in';
        $type = (string) data_get($m, 'type', 'text');
        $mediaUrl = trim((string) data_get($m, 'media_url', ''));

        $inbox = InboxMessage::create([
            'conversation_id' => $convo->id,
            'provider'        => 'instagram',
            'direction'       => $dir,
            'body'            => (string) data_get($m, 'text', ''),
            'media_type'      => $type !== 'text' ? $type : null,
            'status'          => $dir === 'in' ? 'received' : 'sent',
            'meta'            => array_filter([
                'instagram'        => array_filter([
                    'conversation_id' => $igConvId,
                    'message_id'      => data_get($m, 'id'),
                    'account'         => data_get($data, 'account.username'),
                    'account_id'      => data_get($data, 'account.id'),
                    'handle'          => $handle,
                    'avatar'          => data_get($data, 'conversation.avatar'),
                    'media_url'       => $mediaUrl ?: null,
                ], fn ($v) => $v !== null && $v !== ''),
            ]),
            'sent_at'         => now(),
            'delivered_at'    => now(),
        ]);

        // Keep the thread fresh + bump unread on genuine inbound.
        $patch = ['last_message_at' => now(), 'title' => $title, 'provider' => 'instagram'];
        $convo->forceFill($patch)->save();
        if ($dir === 'in' && \Illuminate\Support\Facades\Schema::hasColumn('conversations', 'unread_count')) {
            $convo->increment('unread_count');
        }

        // Real-time fan-out — same event the WhatsApp inbox listens to, so the
        // team-inbox live-updates with the IG thread the moment it arrives.
        event(new MessageReceived($inbox->id, $convo->id, $wsId, $dir, null));

        return $inbox;
    }
}
